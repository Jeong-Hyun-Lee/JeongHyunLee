MSYS2 MINGW32

Packages
- mingw-w64-i686-xmlsec 1.2.24-2
- mingw-w64-i686-libxml2 2.9.4-4
- mingw-w64-i686-libxslt 1.1.29-3
- mingw-w64-i686-openssl 1.0.2.l-1